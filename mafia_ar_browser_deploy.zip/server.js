const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static("public"));

const rooms = new Map();
const ROLES = {
  mafia: { name: "مافيا", team: "mafia", description: "اختر لاعباً ليلاً مع بقية المافيا." },
  doctor: { name: "طبيب", team: "town", description: "احمِ لاعباً واحداً كل ليلة." },
  detective: { name: "محقق", team: "town", description: "افحص لاعباً لمعرفة إن كان من المافيا." },
  citizen: { name: "مواطن", team: "town", description: "ناقش وصوّت خلال النهار." }
};

function code() {
  return crypto.randomBytes(3).toString("hex").toUpperCase();
}
function roomPublic(room) {
  return {
    code: room.code, phase: room.phase, round: room.round,
    hostId: room.hostId,
    players: [...room.players.values()].map(p => ({
      id: p.id, name: p.name, alive: p.alive,
      ready: p.ready,
      role: room.phase === "ended" ? p.role : undefined
    })),
    deadline: room.deadline,
    lastMessage: room.messages.slice(-1)[0] || null
  };
}
function emitRoom(room) {
  io.to(room.code).emit("room:update", roomPublic(room));
}
function sendPrivate(player, event, data) {
  io.to(player.id).emit(event, data);
}
function alive(room) { return [...room.players.values()].filter(p => p.alive); }
function finish(room, winner) {
  room.phase = "ended";
  room.winner = winner;
  room.deadline = null;
  for (const p of room.players.values()) {
    sendPrivate(p, "game:result", {
      winner, roles: [...room.players.values()].map(x => ({ name: x.name, role: ROLES[x.role].name }))
    });
  }
  emitRoom(room);
}
function checkWin(room) {
  const living = alive(room);
  const mafia = living.filter(p => p.role === "mafia").length;
  const town = living.length - mafia;
  if (mafia === 0) finish(room, "town");
  else if (mafia >= town) finish(room, "mafia");
}
function startGame(room) {
  const players = [...room.players.values()];
  if (players.length < 5) return;
  const roles = ["mafia", "doctor", "detective", ...Array(players.length - 3).fill("citizen")];
  for (let i = roles.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [roles[i], roles[j]] = [roles[j], roles[i]];
  }
  players.forEach((p, i) => {
    p.role = roles[i]; p.alive = true; p.ready = false;
    sendPrivate(p, "game:role", { ...ROLES[p.role], round: 1 });
  });
  room.phase = "night"; room.round = 1;
  room.actions = {}; room.votes = {};
  room.messages = [{ system: true, text: "حلّ الليل... نفّذ أصحاب الأدوار السرية مهامهم." }];
  room.deadline = Date.now() + 35000;
  emitRoom(room);
}
function resolveNight(room) {
  const players = room.players;
  const actions = room.actions || {};
  const mafiaTargets = Object.entries(actions).filter(([id]) => players.get(id)?.role === "mafia").map(([,a]) => a.target);
  const killTarget = mafiaTargets[0];
  const saveTarget = Object.entries(actions).find(([id]) => players.get(id)?.role === "doctor")?.[1]?.target;
  const investigate = Object.entries(actions).find(([id]) => players.get(id)?.role === "detective");
  if (killTarget && killTarget !== saveTarget && players.get(killTarget)) {
    players.get(killTarget).alive = false;
    room.messages.push({ system: true, text: `تم العثور على ${players.get(killTarget).name} خارج اللعبة هذا الصباح.` });
  } else {
    room.messages.push({ system: true, text: "مرّت الليلة دون خروج أي لاعب." });
  }
  if (investigate) {
    const target = players.get(investigate[1].target);
    const actor = players.get(investigate[0]);
    if (target && actor) sendPrivate(actor, "game:investigation", {
      name: target.name, result: target.role === "mafia" ? "مافيا" : "ليس من المافيا"
    });
  }
  checkWin(room);
  if (room.phase === "ended") return;
  room.phase = "day"; room.votes = {};
  room.deadline = Date.now() + 60000;
  emitRoom(room);
}
function resolveVote(room) {
  const counts = {};
  for (const target of Object.values(room.votes)) counts[target] = (counts[target] || 0) + 1;
  const sorted = Object.entries(counts).sort((a,b) => b[1]-a[1]);
  if (sorted.length && (sorted.length === 1 || sorted[0][1] > sorted[1][1])) {
    const target = room.players.get(sorted[0][0]);
    if (target && target.alive) {
      target.alive = false;
      room.messages.push({ system: true, text: `صوّتت الأغلبية لإخراج ${target.name}.` });
    }
  } else {
    room.messages.push({ system: true, text: "انتهى التصويت بالتعادل؛ لم يخرج أحد." });
  }
  checkWin(room);
  if (room.phase === "ended") return;
  room.phase = "night"; room.round++;
  room.actions = {}; room.votes = {};
  room.deadline = Date.now() + 35000;
  room.messages.push({ system: true, text: `حلّ الليل رقم ${room.round}.` });
  emitRoom(room);
}

setInterval(() => {
  for (const room of rooms.values()) {
    if (room.phase === "night" && room.deadline && Date.now() >= room.deadline) resolveNight(room);
    else if (room.phase === "day" && room.deadline && Date.now() >= room.deadline) resolveVote(room);
  }
}, 1000);

io.on("connection", socket => {
  socket.on("room:create", ({ name }) => {
    name = String(name || "لاعب").trim().slice(0, 18);
    let c; do { c = code(); } while (rooms.has(c));
    const room = { code:c, hostId:socket.id, players:new Map(), phase:"lobby", round:0,
      messages:[], actions:{}, votes:{}, deadline:null };
    room.players.set(socket.id, { id:socket.id, name, alive:true, ready:false, role:null });
    rooms.set(c, room); socket.join(c);
    socket.emit("room:joined", { code:c }); emitRoom(room);
  });
  socket.on("room:join", ({ code:c, name }) => {
    c = String(c || "").trim().toUpperCase();
    const room = rooms.get(c);
    if (!room || room.phase !== "lobby") return socket.emit("error:message", "الغرفة غير موجودة أو بدأت المباراة.");
    if (room.players.size >= 16) return socket.emit("error:message", "الغرفة ممتلئة.");
    if (room.players.has(socket.id)) return;
    name = String(name || "لاعب").trim().slice(0,18) || "لاعب";
    room.players.set(socket.id, { id:socket.id, name, alive:true, ready:false, role:null });
    socket.join(c); socket.emit("room:joined", { code:c }); emitRoom(room);
  });
  socket.on("player:ready", () => {
    const room = [...rooms.values()].find(r => r.players.has(socket.id));
    if (!room || room.phase !== "lobby") return;
    room.players.get(socket.id).ready = !room.players.get(socket.id).ready; emitRoom(room);
  });
  socket.on("game:start", () => {
    const room = [...rooms.values()].find(r => r.players.has(socket.id));
    if (!room || room.hostId !== socket.id || room.phase !== "lobby") return;
    if (room.players.size < 5) return socket.emit("error:message", "تحتاج إلى 5 لاعبين على الأقل لبدء المباراة.");
    startGame(room);
  });
  socket.on("game:action", ({ target }) => {
    const room = [...rooms.values()].find(r => r.players.has(socket.id));
    if (!room || room.phase !== "night") return;
    const p = room.players.get(socket.id), t = room.players.get(target);
    if (!p?.alive || !t?.alive || p.id === t.id) return;
    if (!["mafia","doctor","detective"].includes(p.role)) return;
    room.actions[socket.id] = { target };
    socket.emit("notice", "تم تسجيل اختيارك السري.");
    const active = alive(room).filter(x => ["mafia","doctor","detective"].includes(x.role));
    if (active.every(x => room.actions[x.id])) resolveNight(room);
  });
  socket.on("game:vote", ({ target }) => {
    const room = [...rooms.values()].find(r => r.players.has(socket.id));
    if (!room || room.phase !== "day") return;
    const p = room.players.get(socket.id), t = room.players.get(target);
    if (!p?.alive || !t?.alive || p.id === t.id) return;
    room.votes[socket.id] = target;
    socket.emit("notice", "تم تسجيل صوتك.");
    if (alive(room).every(x => room.votes[x.id])) resolveVote(room);
  });
  socket.on("chat:send", ({ text }) => {
    const room = [...rooms.values()].find(r => r.players.has(socket.id));
    if (!room || room.phase === "lobby" || room.phase === "ended") return;
    const p = room.players.get(socket.id);
    if (!p?.alive || room.phase !== "day") return;
    text = String(text || "").trim().slice(0,240);
    if (!text) return;
    room.messages.push({ name:p.name, text, system:false });
    if (room.messages.length > 80) room.messages.shift();
    io.to(room.code).emit("chat:new", room.messages.slice(-1)[0]);
  });
  socket.on("disconnect", () => {
    for (const [c, room] of rooms) {
      if (room.players.has(socket.id)) {
        room.players.delete(socket.id);
        if (!room.players.size) rooms.delete(c);
        else {
          if (room.hostId === socket.id) room.hostId = room.players.keys().next().value;
          if (room.phase === "lobby") emitRoom(room);
          else if (room.phase !== "ended") checkWin(room);
        }
        break;
      }
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Mafia AR running on port ${PORT}`));
